---
//aliases: [example, example2]
//tags: 
---
# Marshall Benbow

Teaching pastor at [Grace Community Church](https://gracegso.org/people/marshall-benbow/)
Greensboro, NC
[[The Enneagram | The Reformer]]
