---
//aliases: [example, example2]
//tags: 
---
# Macon Stokes

CEO of [Amplifier](https://amplifier.com)
Austin, TX
[[The Enneagram | The Challenger]]
