---
//aliases: [example, example2]
//tags: 
---
# Alex Kirk

Lead Pastor of [Chatham Community Church](https://www.chathamchurch.org/our-staff)
Basically Chapel Hill, NC
[[The Enneagram#^b48e9d | The Achiever]]  