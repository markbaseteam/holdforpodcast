---
//aliases: [example, example2]
//tags: 
---
# The Enneagram

## One - The Reformer

>Ones are conscientious and ethical, with a strong sense of right and wrong. They are teachers, crusaders, and advocates for change: always striving to improve things, but afraid of making a mistake. Well-organized, orderly, and fastidious, they try to maintain high standards, but can slip into being critical and perfectionistic. They typically have problems with resentment and impatience. _At their Best:_ wise, discerning, realistic, and noble. Can be morally heroic.
from [the enneagram institute](https://www.enneagraminstitute.com/type-1)

## Three  - The Achiever

^b48e9d

>Threes are self-assured, attractive, and charming. Ambitious, competent, and energetic, they can also be status-conscious and highly driven for advancement. They are diplomatic and poised, but can also be overly concerned with their image and what others think of them. They typically have problems with workaholism and competitiveness. _At their Best_: self-accepting, authentic, everything they seem to be—role models who inspire others.
from [the enneagram institute](https://www.enneagraminstitute.com/type-3)

## Eight - The Challenger

>Eights are self-confident, strong, and assertive. Protective, resourceful, straight-talking, and decisive, but can also be ego-centric and domineering. Eights feel they must control their environment, especially people, sometimes becoming confrontational and intimidating. Eights typically have problems with their tempers and with allowing themselves to be vulnerable. _At their Best_: self- mastering, they use their strength to improve others' lives, becoming heroic, magnanimous, and inspiring.
from [the enneagram institute](https://www.enneagraminstitute.com/type-8)