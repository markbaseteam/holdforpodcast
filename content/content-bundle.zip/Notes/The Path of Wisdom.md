---
//aliases: [example, example2]
//tags: 
---
# The Path of Wisdom

```dataview
table 
from [[The Path of Wisdom]]
```