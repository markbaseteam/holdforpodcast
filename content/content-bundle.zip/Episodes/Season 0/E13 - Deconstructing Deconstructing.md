---
//aliases: [example, example2]
tags: HFPDOTCOM, webpage
---
# E13 - Deconstructing Deconstructing

[[Marshall]], [[Alex]], and [[Macon]] think about what's going on with what the cool kids call, "Deconstruction," which, up to this point in history, has been referred to as, "thinking about your beliefs and how you came by them."

<iframe title="Deconstructing Deconstructing" allowtransparency="true" height="150" width="100%" style="border: none; min-width: min(100%, 430px);" scrolling="no" data-name="pb-iframe-player" src="https://www.podbean.com/player-v2/?i=wn4k7-12f5f3e-pb&from=pb6admin&share=1&download=1&rtl=0&fonts=Arial&skin=1&font-color=auto&logo_link=episode_page&btn-skin=7"></iframe>

## Show Notes
