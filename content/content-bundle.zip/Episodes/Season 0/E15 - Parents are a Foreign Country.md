---
//aliases: [example, example2]
tags: HFPDOTCOM, webpage
home: true 
---
# E15 - Parents are a Foreign Country

[[Alex]] and [[Macon]] explore the impossible possibility of understanding one's parents and having one's children understand you. 

<iframe title="Parents are a Foreign Country" allowtransparency="true" height="150" width="100%" style="border: none; min-width: min(100%, 430px);" scrolling="no" data-name="pb-iframe-player" src="https://www.podbean.com/player-v2/?i=ui73j-1312ac3-pb&from=pb6admin&share=1&download=1&rtl=0&fonts=Arial&skin=1&font-color=auto&logo_link=episode_page&btn-skin=7"></iframe>

## Show Notes
- [Nietzsche and the collective degeneration of man](https://en.wikipedia.org/wiki/Master–slave_morality#Society)
- [Lex Fridman, Second Eric Weinstein Interview](https://lexfridman.com/eric-weinstein-2/)
- The [Bene Gesserit](https://dune.fandom.com/wiki/Bene_Gesserit)
- [The Body Keeps the Score](https://www.besselvanderkolk.com/resources/the-body-keeps-the-score)
- [Marco Polo](https://www.marcopolo.me)
- Alex's [Greenhouse Retreats](https://greenhouseretreats.substack.com)
- [Med Deli](https://mediterraneandeli.com/chapel-hill)

