---
//aliases: [example, example2]
tags: HFPDOTCOM, webpage
---
# E14 - Shamely Guilt

Marshall and Macon discuss Marshal's guilt, Macon's shamelessness, Purity Culture, teenagers, and [[The Path of Wisdom]].

<iframe title="Shamely Guilt" allowtransparency="true" height="150" width="100%" style="border: none; min-width: min(100%, 430px);" scrolling="no" data-name="pb-iframe-player" src="https://www.podbean.com/player-v2/?i=3kqs8-1308405-pb&from=pb6admin&share=1&download=1&rtl=0&fonts=Arial&skin=1&font-color=auto&logo_link=episode_page&btn-skin=7"></iframe>

## Show Notes
- [[The Enneagram#^154b70 | Enneagram One]]
- [[The Enneagram#^527dd1 | Enneagram Eight]]
